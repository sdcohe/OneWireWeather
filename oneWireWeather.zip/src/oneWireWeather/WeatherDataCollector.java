/* SVN FILE: $Id: WeatherDataCollector.java 134 2013-07-19 19:32:22Z seth $ */
/**
* One Wire Weather : Weather station daemon for a 1-wire weather station
*
* $Author: seth $
* $Revision: 134 $
* $Date: 2013-07-19 15:32:22 -0400 (Fri, 19 Jul 2013) $
* $LastChangedBy: seth $
* $LastChangedDate: 2013-07-19 15:32:22 -0400 (Fri, 19 Jul 2013) $
* $URL: https://balto:8443/svn/Projects/OneWireWeather/src/oneWireWeather/WeatherDataCollector.java $
* $Copyright: (c)2007 Seth Cohen. All Rights Reserved $
* $License: This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.$
*/

package oneWireWeather;

import java.util.*;

import com.dalsemi.onewire.*;
import com.dalsemi.onewire.adapter.*;
//import com.dalsemi.onewire.application.monitor.NetworkDeviceMonitor;
import com.dalsemi.onewire.container.OneWireContainer;
//import com.dalsemi.onewire.container.SwitchContainer;
import com.dalsemi.onewire.utils.OWPath;

public class WeatherDataCollector implements Runnable // , DeviceMonitorEventListener
{

    private StationConfiguration m_configuration;
    private DSPortAdapter m_adapter;
    private WeatherStation m_station;
    private boolean m_bQuit = false;

    // declare these at the class level so they can retain their value between passes 
    private HashMap<String,Object> auxValues = new HashMap<String,Object>();
    private float temp = Float.MIN_VALUE;
    private float windSpeed = Float.MIN_VALUE;
    private float humidity = Float.MIN_VALUE;
    private int windDirection = WindDirectionSensor.WIND_DIRECTION_ERROR;
    private float pressure = Float.MIN_VALUE;
    private float rainfall = Float.MIN_VALUE;
    private float solar = Float.MIN_VALUE;
    private int lightning = Integer.MIN_VALUE;
    private float indoorTemperature = Float.MIN_VALUE;
    private float indoorHumidity = Float.MIN_VALUE;

    private Hashtable<String, HardwareSensor> m_sensorList = new Hashtable<String, HardwareSensor>();
    private Hashtable<String, Long> m_intervalList = new Hashtable<String, Long>();
    private Hashtable<String, SensorConfiguration> configurationEntries;

    public WeatherDataCollector(StationConfiguration config, WeatherStation station)
    {
	m_configuration = config;
	m_station = station;

	// get the configures sensor list from the configuration file
	configurationEntries = config.getSensorList();

	// set hardware configuration
	m_adapter = createAdapter();

	if (m_adapter != null)
	{
	    // get list of devices and paths on net
	    Hashtable<String, OWPath> devicePaths = StationConfiguration.walkNet(m_adapter);

	    // look for devices on bus but not configured
	    for (Enumeration<String> keys = devicePaths.keys(); keys.hasMoreElements(); )
	    {
		String address = (String)keys.nextElement();
		OWPath path = (OWPath)devicePaths.get(address);

		// check if is in config file
		if (!configurationEntries.containsKey(address))
		{
		    // open path and get container so we can try to log what type of device this is
		    //  This info will be handy for debugging adn modifying the config file by hand  
		    try
		    {
			path.open();
			OneWireContainer owc = m_adapter.getDeviceContainer(address);
			ErrorLog.logError("Address on bus not in config file " + owc.getName() + " " + address + " path " + path);
		    }
		    catch (Exception e)
		    {
			ErrorLog.logError("Address on bus not in config file " + address + " path " + path);
		    }

		}
		else
		{
		    SensorConfiguration sensor = configurationEntries.get(address);
		    SensorType type = WeatherStation.getSensorTypeForUsage(sensor.getUsageType());
		    ErrorLog.logError("Found address on bus: " + sensor.getName() + " " + type.getDescription() + " " + address + " at path " + path);
		}
	    }

	    // walk through config and match up with bus, report devices not found on bus
	    for (Enumeration<SensorConfiguration> e = configurationEntries.elements(); e.hasMoreElements() ;) 
	    {
		SensorConfiguration sensor = (SensorConfiguration)e.nextElement();
		OWPath path = devicePaths.get(sensor.getID());

		if (path != null)
		{
		    sensor.setPath(path);
		    addSensorToList(sensor);
		}
		else
		{
		    ErrorLog.logError("Address in config file but not on bus " + sensor.getName() + " " + sensor.getID());
		}
	    }

	}
    }

    /**
     * @param sensorsOnBus
     * @param sensor
     */
    private void addSensorToList(SensorConfiguration sensor)
    {
	int usageType = sensor.getUsageType();
	long currentTime = System.currentTimeMillis();
	HardwareSensor newSensor = null;

	// instantiate the correct hardware sensor and do an initial read
	switch (usageType)
	{
	    case SensorType.MAIN_INDOOR_TEMP:
	    case SensorType.MAIN_OUTDOOR_TEMP:
	    case SensorType.AUX_INDOOR_TEMP:
	    case SensorType.AUX_OUTDOOR_TEMP:
		newSensor = new TemperatureSensor(m_adapter, sensor);

		if (newSensor.isEnabled())
		{
		    if (usageType == SensorType.MAIN_OUTDOOR_TEMP)
		    {
			temp = ((TemperatureSensor)newSensor).getTemperature();
		    }
		    if (usageType == SensorType.MAIN_INDOOR_TEMP)
		    {
			indoorTemperature = ((TemperatureSensor)newSensor).getTemperature();
		    }
		}
		break;

	    case SensorType.AAG_WIND_DIRECTION:
		newSensor = new AAGWindDirectionSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    windDirection = ((WindDirectionSensor)newSensor).getWindDirection();
		}
		break;

	    case SensorType.AAG_WIND_SPEED:
		newSensor = new AAGWindSpeedSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    windSpeed = ((WindSpeedSensor)newSensor).getWindSpeed();
		}
		break;

	    case SensorType.OUTDOOR_HUMIDITY:
	    case SensorType.INDOOR_HUMIDITY:
		newSensor = new HumiditySensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    if (usageType == SensorType.OUTDOOR_HUMIDITY)
			humidity = ((HumiditySensor)newSensor).getHumidity();
		    else
			indoorHumidity = ((HumiditySensor)newSensor).getHumidity();
		}
		break;

	    case SensorType.PRESSURE:
		newSensor = new BarometerSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{			
		    pressure = ((BarometerSensor)newSensor).getPressure();
		}
		break;

	    case SensorType.RAIN_COUNTER:
		newSensor = new RainSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{			
		    rainfall = ((RainSensor)newSensor).getRainCount();
		}
		break;

	    case SensorType.SOLAR:
		newSensor = new SolarSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    solar = ((SolarSensor)newSensor).getSolarLevel();
		}
		break;

	    case SensorType.LIGHTNING_COUNTER:
		newSensor = new LightningSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    lightning = ((LightningSensor)newSensor).getLightningCount();
		}
		break;

	    case SensorType.ADS_WIND_DIRECTION:
		newSensor = new ADSWindDirectionSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    windDirection = ((WindDirectionSensor)newSensor).getWindDirection();
		}
		break;

	    case SensorType.ADS_WIND_SPEED:
		newSensor = new ADSWindSpeedSensor(m_adapter, sensor);
		if (newSensor.isEnabled())
		{
		    windSpeed = ((WindSpeedSensor)newSensor).getWindSpeed();
		}
		break;

	}

	if (newSensor != null)
	{
	    synchronized (m_sensorList)
	    {
		m_sensorList.put(sensor.getID(), newSensor);
		m_intervalList.put(sensor.getID(), new Long(currentTime + sensor.getPollOffset()));
	    }
	}
    }

    private DSPortAdapter createAdapter()
    {
	// create hardware configuration
	try
	{
	    ErrorLog.logError("Getting adapter " + m_configuration.getAdapterName() + " on port " + m_configuration.getAdapterPortName());

	    m_adapter = OneWireAccessProvider.getAdapter(m_configuration.getAdapterName(), 
		    m_configuration.getAdapterPortName());

	    StringBuilder builder = new StringBuilder();
	    builder.append("  Class name: " + m_adapter.getClass().getName());
	    builder.append(" Port type: " + m_adapter.getPortTypeDescription() + "\n");
	    builder.append("  Class version: " + m_adapter.getClassVersion() + "\n");
	    builder.append("  Adapter name: " + m_adapter.getAdapterName());
	    builder.append(" version: " + m_adapter.getAdapterVersion());
	    builder.append(" address: " + m_adapter.getAdapterAddress() + "\n");
	    builder.append("  Can break: " + m_adapter.canBreak());
	    builder.append(" deliver power: " + m_adapter.canDeliverPower());
	    builder.append(" deliver smart power: " + m_adapter.canDeliverSmartPower());
	    builder.append(" flex: " + m_adapter.canFlex());
	    builder.append(" hyperdrive: " + m_adapter.canHyperdrive());
	    builder.append(" overdrive: " + m_adapter.canOverdrive());
	    builder.append(" program: " + m_adapter.canProgram());
	    builder.append(" Speed: " + m_adapter.getSpeed());

	    ErrorLog.logError("Adapter found");
	    ErrorLog.logError(builder.toString());

	}
	catch (OneWireException e)
	{
	    ErrorLog.logError("Error creating the adapter: " + e);
	    return null;
	}

	resetBus();

	return m_adapter;
    }

    public synchronized void setQuitFlag()
    {
	m_bQuit = true;
    }

    private void resetBus()
    {
	if (m_adapter == null)
	    return;

	try
	{
	    if (!m_adapter.adapterDetected())
	    {
		ErrorLog.logError("No adapter detected in resetBus()");
		// *** test will this even work?
		//		m_adapter = createAdapter();
		return;
	    }
	}
	catch (OneWireException ex)
	{
	    ErrorLog.logError("Exception in resetBus() " + ex);
	    return;
	}

	// reset the 1-wire bus
	try
	{
	    int result = m_adapter.reset();
	    m_adapter.setSearchAllDevices();
	    m_adapter.targetAllFamilies();

	    if (result == DSPortAdapter.RESET_NOPRESENCE)
	    {
		ErrorLog.logError("Warning: Reset indicates no Device Present");
	    }
	    else if (result == DSPortAdapter.RESET_SHORT)
	    {
		ErrorLog.logError("Warning: Reset indicates 1-Wire bus is shorted.");
	    }
	}
	catch (OneWireException ex)
	{
	    ErrorLog.logError("Exception resetting the bus: " + ex);
	}

	// TODO: reset hub?
    }

    public void run() 
    {
	int second;
	int lastSampleSecond = -99;
	Calendar cal;
	WeatherData data;

	while (!m_bQuit)
	{
	    try
	    {
		Thread.sleep(m_configuration.getHardwarePollInterval());
	    }
	    catch (InterruptedException e) 
	    {
		if (m_bQuit)
		    break;
	    }

	    // ensure we only take measurements once a second
	    cal = Calendar.getInstance();
	    second = cal.get(Calendar.SECOND);

	    if (second != lastSampleSecond && !m_bQuit)
	    {
		lastSampleSecond = second;

		try
		{
		    if (m_adapter != null && m_adapter.adapterDetected())
		    {
			m_adapter.beginExclusive(true);

			resetBus();

			// m_adapter.setSpeed(DSPortAdapter.SPEED_FLEX);

			data = acquireData();

			// signal station
			m_station.receiveMessage(data);

		    }
		    else
		    {
			// log an adapter error
			ErrorLog.logError("No adapter detected in run()");
			
			// we couldn't even find an adapter
			// clear data to show we got no reading at all
			data = new WeatherData(System.currentTimeMillis(), Float.MIN_VALUE, Float.MIN_VALUE, 
				Float.MIN_VALUE, WindDirectionSensor.WIND_DIRECTION_ERROR, Float.MIN_VALUE, Float.MIN_VALUE, Float.MIN_VALUE, Float.MIN_VALUE, Float.MIN_VALUE, 0);

			// try and recover?
			// m_adapter.freePort();
			// m_adapter = createAdapter();
		    }
		}
		catch (OneWireException ex)
		{
		    // log an exception detecting the adapter
		    ErrorLog.logError("Data acquisition error: " + ex);
		}
		finally
		{
		    if (m_adapter != null)
		    {
			m_adapter.endExclusive();
		    }
		}
	    }
	}

	// clean up adapter port - this causes the serial port to be closed properly
	try 
	{
	    m_adapter.freePort();
	    m_adapter = null;
	} 
	catch (Exception e) 
	{
	    // just log exception, no action to take
	    ErrorLog.logError("Error exiting run");
	    ErrorLog.logStackTrace(e);
	}

    }

    private WeatherData acquireData()
    {
	WeatherData data;
	long currentMillis = Calendar.getInstance().getTimeInMillis();

	synchronized (m_sensorList)
	{
	    for (Enumeration<HardwareSensor> e = m_sensorList.elements(); e.hasMoreElements() ;) 
	    {
		HardwareSensor sensor = (HardwareSensor)e.nextElement();

		if (currentMillis >= m_intervalList.get(sensor.getID()).longValue())
		{
		    switch(sensor.getUsageType())
		    {
			case SensorType.MAIN_OUTDOOR_TEMP:
			    temp = ((TemperatureSensor)sensor).getTemperature();
			    break;

			case SensorType.OUTDOOR_HUMIDITY:
			    humidity = ((HumiditySensor)sensor).getHumidity();
			    break;

			case SensorType.AAG_WIND_DIRECTION:
			case SensorType.ADS_WIND_DIRECTION: 
			    windDirection = ((WindDirectionSensor)sensor).getWindDirection();
			    break;

			case SensorType.AAG_WIND_SPEED:
			case SensorType.ADS_WIND_SPEED:
			    windSpeed = ((WindSpeedSensor)sensor).getWindSpeed();
			    break;

			case SensorType.AUX_OUTDOOR_TEMP:
			case SensorType.AUX_INDOOR_TEMP:
			    auxValues.put(sensor.getID(), 
				    ((TemperatureSensor)sensor).getTemperature());
			    break;

			case SensorType.PRESSURE:
			    pressure = ((BarometerSensor)sensor).getPressure();
			    break;

			case SensorType.RAIN_COUNTER:
			    rainfall = ((RainSensor)sensor).getRainCount();
			    break;

			case SensorType.MAIN_INDOOR_TEMP:
			    indoorTemperature = ((TemperatureSensor)sensor).getTemperature();
			    break;

			case SensorType.INDOOR_HUMIDITY:
			    indoorHumidity = ((HumiditySensor)sensor).getHumidity();
			    break;

			case SensorType.SOLAR:
			    solar = ((SolarSensor)sensor).getSolarLevel();
			    break;

			case SensorType.LIGHTNING_COUNTER:
			    lightning = ((LightningSensor)sensor).getLightningCount();
			    break;

		    }

		    m_intervalList.put(sensor.getID(), new Long(currentMillis + sensor.getPollFrequency()));
		}
	    }
	}

	data = new WeatherData(System.currentTimeMillis(), temp, humidity, 
		windSpeed, windDirection, rainfall, pressure, indoorTemperature, indoorHumidity, solar, lightning);

	// add aux values *** do we need to expire old values?
	data.putExtraSensorValues(auxValues);

	return data;
    }

    //    private Hashtable<String, WeatherSensor> getSensorsOnBus()
    //    {
    //	ErrorLog.logError("Searching 1-Wire bus for sensors");
    //
    //	Hashtable<String, WeatherSensor> sensors = new Hashtable<String, WeatherSensor>();
    //
    //	try
    //	{
    //	    m_adapter.reset();
    //
    //	    // search for all 1-wire devices & add to text area
    //	    //        System.out.println("Adapter: " + adapter.getAdapterName());
    //	    //        System.out.println("Port: " + adapter.getPortName() + "\n");
    //
    //	    // get exclusive use of adapter
    //	    m_adapter.beginExclusive(true);
    //
    //	    // search main bus with no couplers
    //	    searchActiveBranch("", -1, sensors);
    //
    //	    // clear any previous search restrictions
    //	    m_adapter.setSearchAllDevices();
    //	    m_adapter.targetAllFamilies();
    //	    m_adapter.targetFamily(0x001f);
    //	    m_adapter.setSpeed(DSPortAdapter.SPEED_REGULAR);
    //
    //	    // enumerate through all the 1-Wire devices found
    //	    Enumeration<?> owdEnum;
    //	    OneWireContainer owd;
    //
    //	    // is there any DS2409 MicroLAN Couplers?
    //	    if (m_adapter.findFirstDevice())
    //	    {
    //		for (owdEnum = m_adapter.getAllDeviceContainers(); owdEnum.hasMoreElements(); )
    //		{
    //		    owd = (OneWireContainer)owdEnum.nextElement();
    //		    //            System.out.println("MicroLAN Coupler Found at " + owd.getAddressAsString());
    //
    //		    //            System.out.println("Main Port Devices Found:");
    //		    //            activateCoupler(adapter, owd.getAddressAsString(), 0);
    //		    searchActiveBranch(owd.getAddressAsString(), 0, sensors);
    //		    //            deactivateCoupler(adapter, owd.getAddressAsString(), 0);
    //
    //		    //            System.out.println("Aux Port Devices Found:");
    //		    //            activateCoupler(adapter, owd.getAddressAsString(), 1);
    //		    searchActiveBranch(owd.getAddressAsString(), 1, sensors);
    //		    //            deactivateCoupler(adapter, owd.getAddressAsString(), 1);
    //		}
    //	    }
    //
    //	    //        // walk sensors list and print
    //	    //        for (Enumeration<WeatherSensor> e = sensors.elements(); e.hasMoreElements() ;) 
    //	    //        {
    //	    //            WeatherSensor sensor = e.nextElement();
    //	    //            System.out.println(sensor.toString());
    //	    //        }
    //	    //        
    //	    //        System.out.println("\nDone\n");
    //
    //	    // free up the serial port
    //	    m_adapter.endExclusive();
    //	    //        adapter.freePort();
    //	}
    //	catch (OneWireException e)
    //	{
    //	    System.out.println("Error Serching the 1-Wire Bus");
    //	}
    //
    //	ErrorLog.logError("Done searching bus");
    //
    //	return sensors;
    //    }

    //    private void activateCoupler(String addr, int channel) throws OneWireException
    //    {
    //	byte[]  state;
    //
    //	OneWireContainer1F owc = new OneWireContainer1F(m_adapter, addr);
    //	state = owc.readDevice();
    //	owc.setLatchState(channel, true, false, state);
    //	owc.writeDevice(state);
    //    }
    //
    //    private void deactivateCoupler(String addr, int chan) throws OneWireException
    //    {
    //	byte[]  state;
    //
    //	OneWireContainer1F owc = new OneWireContainer1F(m_adapter, addr);
    //	state = owc.readDevice();
    //	owc.setLatchState(chan, false, false, state);
    //	owc.writeDevice(state);
    //    }

    //    private boolean searchActiveBranch(String couplerAddress, int port, Hashtable<String, WeatherSensor> sensors) throws OneWireException
    //    {
    //	boolean found = false;
    //
    //	if (couplerAddress != null && couplerAddress.length() > 0)
    //	{
    //	    activateCoupler(couplerAddress, port);
    //	}
    //
    //	// clear any previous search restrictions
    //	m_adapter.setSearchAllDevices();
    //	m_adapter.targetAllFamilies();
    //	m_adapter.excludeFamily(0x001f);
    //	m_adapter.setSpeed(DSPortAdapter.SPEED_REGULAR);
    //
    //	// enumerate through all the 1-Wire devices found
    //	Enumeration<?> owdEnum;
    //	OneWireContainer owd;
    //
    //	for (owdEnum = m_adapter.getAllDeviceContainers(); owdEnum.hasMoreElements();)
    //	{
    //	    owd = (OneWireContainer)owdEnum.nextElement();
    //	    WeatherSensor sensor = new WeatherSensor(owd.getAddressAsString(), 0, 0.0f, 0.0f, 0, 0, false, false, couplerAddress, port);
    //	    //	    sensor.setCouplerAddress(couplerAddress);
    //	    //	    sensor.setCouplerPort(port);
    //	    if (!sensors.containsKey(owd.getAddressAsString()))
    //	    {
    //		sensors.put(owd.getAddressAsString(), sensor);
    //		String coupler = "";
    //		if (couplerAddress != null && couplerAddress.length() > 0)
    //		{
    //		    coupler = " on " + couplerAddress + " " + port;
    //		}
    //		ErrorLog.logError("Found Sensor: Addr: " + owd.getAddressAsString() + " P/N: " + owd.getName() + coupler);
    //	    }
    //	    found = true;
    //	}
    //
    //	//      if (!found)
    //	//        System.out.println("None");
    //
    //	if (couplerAddress != null && couplerAddress.length() > 0)
    //	{
    //	    deactivateCoupler(couplerAddress, port);
    //	}
    //
    //	return found;
    //    }

//    private Hashtable<String, OWPath> walkNet(DSPortAdapter adapter)
//    {
//	// vector for holding a list of paths to be searched
//	Vector<OWPath> pathsToSearch = new Vector<OWPath>();
//	boolean searchResult = false;
//
//	// hash table for holding the OWPath objects for each device container.
//	Hashtable<String, OWPath> devicePathHash = new Hashtable<String, OWPath>();
//
//	try
//	{
//	    // seed list with main branch
//	    pathsToSearch.addElement(new OWPath(adapter));
//
//	    // acquire the adapter
//	    adapter.beginExclusive(true);
//
//	    // setup the search
//	    adapter.setSearchAllDevices();
//	    adapter.targetAllFamilies();
//	    adapter.setSpeed(DSPortAdapter.SPEED_REGULAR);
//
//	    // walk path and get all devices on branch.
//	    // if any switches are found, add them to the list of paths to search
//	    // search through all of the paths
//	    for (int i = 0; i < pathsToSearch.size(); i++)
//	    {
//		// set searches to not use reset
//		adapter.setNoResetSearch();
//
//		// get the next path to search and open it
//		OWPath path = (OWPath)pathsToSearch.elementAt(i);
//
//		try
//		{
//		    // try to open the current path
//		    path.open();
//		}
//		catch(Exception e)
//		{
//		    // if opening the path failed, log an error and continue on to the next path
//		    ErrorLog.logError("walkNet(): Error opening path " + path.toString());
//		    continue;
//		}
//
//		// get the devices on the currently open path
//		searchResult = adapter.findFirstDevice();
//
//		// loop while devices found
//		while (searchResult)
//		{
//		    // get the 1-Wire address
//		    String address = adapter.getAddressAsString();
//
//		    // check if the device already exists in the hash table of addresses
//		    if (!devicePathHash.containsKey(address))
//		    {
//			OneWireContainer owc = adapter.getDeviceContainer(address);
//
//			// check to see if it's a switch.  If so, add it to the paths to be searched
//			//	if we haven't already searched it
//			if (owc instanceof SwitchContainer) 
//			{
//			    SwitchContainer sc = (SwitchContainer)owc;
//			    byte[] state = sc.readDevice();
//			    for (int j = 0; j < sc.getNumberChannels(state); j++)
//			    {
//				OWPath tmp = new OWPath(adapter, path);
//				tmp.add(owc, j);
//				if (!pathsToSearch.contains(tmp))
//				{
//				    pathsToSearch.addElement(tmp);
//				}
//			    }
//			}
//
//			// save off the address and path
//			synchronized(devicePathHash)
//			{
//			    devicePathHash.put(address, path);
//			}
//		    }
//		    // check if the existing device moved
//		    else if (!path.equals((OWPath)devicePathHash.get(address)))
//		    {
//			// if it has moved, add the new address/path pair
//			synchronized(devicePathHash)
//			{
//			    devicePathHash.put(address, path);
//			}
//		    }
//
//		    // find the next device on this branch
//		    path.open();
//		    searchResult = adapter.findNextDevice();
//		}
//
//		path.close();
//	    }
//
//	    // clean up after ourselves
//	    adapter.setSearchAllDevices();
//	    adapter.endExclusive();
//	}
//	catch (OneWireException e)
//	{
//	    ErrorLog.logError("Error Serching the 1-Wire Bus");
//	}
//
//	return devicePathHash;
//
//    }
}
